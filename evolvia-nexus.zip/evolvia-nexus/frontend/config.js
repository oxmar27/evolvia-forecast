// Public settings only. NEVER put secret keys in this file.
window.APP_CONFIG = {
  API_URL: "http://localhost:8000",
  TURNSTILE_SITE_KEY: ""   // public site key from Cloudflare Turnstile (optional)
};
