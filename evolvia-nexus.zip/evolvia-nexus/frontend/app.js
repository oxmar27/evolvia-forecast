(function () {
  "use strict";
  var cfg = window.APP_CONFIG, $ = function (id) { return document.getElementById(id); };
  var fileInput = $("file"), statusEl = $("status"), captchaToken = "";

  /* ---------- languages: English / Arabic ---------- */
  var T = {
    en: {
      tag: "Together to evolve, together to rise", h2: "Upload any numbers. Get forecasts and insights.",
      hp: "Sales, prices, demand: drop a CSV and we pick the best model for it.", choose: "Choose a CSV file",
      pick: "What do you want to predict?", go: "Analyze", needCsv: "Please choose a .csv file.",
      tooBig: "The file is larger than 10 MB.", reading: "Reading your file...", noNum: "No numeric columns found in this file.",
      foundDate: "{rows} rows. Dates found in \"{col}\": we will forecast the future.",
      noDate: "{rows} rows. No dates found: we will learn from the other columns.",
      analyzing: "Analyzing... this can take a minute or two.", best: "Best method:", err: "typical error about",
      compare: "Method comparison (average error, lower is better)", matters: "What matters most", failed: "Request failed"
    },
    ar: {
      tag: "معًا نتطوّر، معًا ننهض", h2: "ارفع أي أرقام. واحصل على توقعات وتحليلات.",
      hp: "مبيعات، أسعار، طلب: ارفع ملف CSV ونحن نختار أفضل نموذج له.", choose: "اختر ملف CSV",
      pick: "ما الذي تريد توقعه؟", go: "حلّل", needCsv: "من فضلك اختر ملفًا بصيغة csv.",
      tooBig: "حجم الملف أكبر من 10 ميجابايت.", reading: "جاري قراءة الملف...", noNum: "لا توجد أعمدة رقمية في هذا الملف.",
      foundDate: "{rows} صف. وجدنا تواريخ في العمود \"{col}\": سنتوقع المستقبل.",
      noDate: "{rows} صف. لا توجد تواريخ: سنتعلم من باقي الأعمدة.",
      analyzing: "جاري التحليل... قد يستغرق دقيقة أو دقيقتين.", best: "أفضل طريقة:", err: "متوسط الخطأ حوالي",
      compare: "مقارنة الطرق (متوسط الخطأ، الأقل أفضل)", matters: "أكثر ما يؤثر", failed: "فشل الطلب"
    }
  };
  Object.assign(T.en, {
    ready: "Your forecast for \"{col}\" is ready",
    acc: "In past tests, this method was off by about {e}% on average.",
    topFactor: "The factor that matters most is \"{k}\" ({p}% of the effect).",
    predRows: "We also predicted {n} rows where the value was empty (see the table below).",
    tsPlain: "Over the next {n} {u}, we expect on average about {avg}, {dir} {pct}% compared with the previous {n} {u}. Highest expected: {top} on {date}.",
    up: "up", down: "down", cmpNote: "The method with the smallest error was picked automatically:",
    lgData: "Your data", lgFc: "Forecast", lgBand: "Likely range",
    cap: "Shaded area = where the real value will most likely fall (about 80% chance).",
    dl: "Download forecast (CSV)", more: "How we picked this method"
  });
  Object.assign(T.ar, {
    ready: "توقعك لـ \"{col}\" جاهز",
    acc: "في اختباراتنا السابقة، كان متوسط خطأ هذه الطريقة حوالي {e}%.",
    topFactor: "أهم عامل هو \"{k}\" ({p}% من التأثير).",
    predRows: "وتوقعنا أيضًا {n} صف كانت قيمته فارغة (الجدول بالأسفل).",
    tsPlain: "خلال الـ {n} {u} القادمة نتوقع في المتوسط حوالي {avg}، أي {dir} بنسبة {pct}% مقارنة بالـ {n} {u} السابقة. أعلى قيمة متوقعة: {top} بتاريخ {date}.",
    up: "ارتفاعًا", down: "انخفاضًا", cmpNote: "اختار النظام تلقائيًا الطريقة الأقل خطأً:",
    lgData: "بياناتك", lgFc: "التوقع", lgBand: "المدى المحتمل",
    cap: "المنطقة المظللة = المكان المرجّح للقيمة الحقيقية (احتمال حوالي 80%).",
    dl: "تحميل التوقع (CSV)", more: "كيف اخترنا هذه الطريقة"
  });
  Object.assign(T.en, {
    what: "What do you need?", tAnalysis: "Analysis only (understand my data)", tForecast: "Forecast only", tBoth: "Analysis + forecast",
    readyA: "Your analysis of \"{col}\" is ready", aTitle: "What we found in your data",
    aAvg: "Average", aMid: "Middle value", aLow: "Lowest", aHigh: "Highest", aRows: "Rows",
    trend_up: "Overall trend: going up, about {g}% from the start to the end of your data.",
    trend_down: "Overall trend: going down, about {g}% from the start to the end of your data.",
    trend_flat: "Overall trend: roughly flat.",
    trendRecent: "The last {k} {u} changed by {c}% compared with the {k} {u} before them.",
    pWeekday: "Typical weekday pattern (100 = your average)", pMonth: "Typical month pattern (100 = your average)",
    ext: "Highest: {hi} on {hd}. Lowest: {lo} on {ld}.",
    anTitle: "Unusual values", anNone: "No unusual values found.", anItem: "{d}: {v} (we expected about {e})",
    corrTitle: "What moves together with it", corrNote: "A relationship does not prove that one thing causes the other.",
    distTitle: "How the values are spread", outl: "Extreme values found: {n}."
  });
  Object.assign(T.ar, {
    what: "ماذا تريد؟", tAnalysis: "تحليل فقط (أفهم بياناتي)", tForecast: "توقع فقط", tBoth: "تحليل + توقع",
    readyA: "تحليل \"{col}\" جاهز", aTitle: "ماذا وجدنا في بياناتك",
    aAvg: "المتوسط", aMid: "القيمة الوسطى", aLow: "الأقل", aHigh: "الأعلى", aRows: "عدد الصفوف",
    trend_up: "الاتجاه العام: صعودي، بحوالي {g}% من بداية بياناتك لنهايتها.",
    trend_down: "الاتجاه العام: هبوطي، بحوالي {g}% من بداية بياناتك لنهايتها.",
    trend_flat: "الاتجاه العام: ثابت تقريبًا.",
    trendRecent: "آخر {k} {u} تغيّرت بنسبة {c}% مقارنة بالـ {k} {u} التي قبلها.",
    pWeekday: "النمط المعتاد لأيام الأسبوع (100 = متوسطك)", pMonth: "النمط المعتاد للشهور (100 = متوسطك)",
    ext: "الأعلى: {hi} بتاريخ {hd}. الأقل: {lo} بتاريخ {ld}.",
    anTitle: "قيم غير معتادة", anNone: "لم نجد قيمًا غير معتادة.", anItem: "{d}: {v} (توقعنا حوالي {e})",
    corrTitle: "ما يتحرك معه", corrNote: "العلاقة لا تعني أن أحدهما يسبب الآخر.",
    distTitle: "توزيع القيم", outl: "عدد القيم المتطرفة: {n}."
  });
  // server messages (English) -> Arabic
  var PAT = [
    [/^Too many rows \(max (\d+)\).*/, "عدد الصفوف كبير جدًا (الحد الأقصى $1)."],
    [/^File is too large \(max (\d+) MB\).*/, "الملف كبير جدًا (الحد الأقصى $1 ميجابايت)."],
    [/^Request is too large.*/, "الطلب كبير جدًا."],
    [/^Too many requests.*/, "طلبات كثيرة جدًا. انتظر دقيقة."],
    [/^Daily analysis limit.*/, "وصلت للحد اليومي للتحليلات. جرّب غدًا."],
    [/^Captcha check failed.*/, "فشل التحقق من الكابتشا. حاول مرة أخرى."],
    [/^The server is busy.*/, "الخادم مشغول بتحليلات أخرى. جرّب بعد دقيقة."],
    [/^Could not read the file.*/, "تعذّرت قراءة الملف كجدول CSV."],
    [/^Not enough rows.*/, "عدد الصفوف غير كافٍ (نحتاج 30 على الأقل)."],
    [/^Filled (\d+) missing values.*/, "تمت تعبئة $1 قيمة ناقصة بالتقدير بين القيم المجاورة."],
    [/^Short history.*/, "التاريخ قصير (أقل من 3 دورات موسمية كاملة): قد تكون التوقعات أقل دقة."],
    [/^Ignored non-numeric columns: (.*)/, "تم تجاهل الأعمدة غير الرقمية: $1"],
    [/^Small dataset.*/, "بيانات قليلة (أقل من 100 صف): قد تكون النتائج غير مستقرة."],
    [/^Methods not available.*/, "بعض الطرق غير متاحة على هذا الخادم."],
    [/^Showing only the first 1000.*/, "نعرض أول 1000 توقع فقط."],
    [/^Too many missing values.*/, "قيم ناقصة كثيرة جدًا في عمود التوقع."],
    [/^Could not figure out the date.*/, "تعذّر تحديد نمط التواريخ."],
    [/^Column .* not found.*/, "العمود غير موجود."],
    [/^Something went wrong.*/, "حدث خطأ من جهتنا. حاول لاحقًا."]
  ];
  var lang = "en", lastSay = null, lastResult = null, lastTarget = "";
  try { lang = localStorage.getItem("lang") || ((navigator.language || "").slice(0, 2) === "ar" ? "ar" : "en"); } catch (e) {}
  function tr(k, v) { return (T[lang][k] || T.en[k] || k).replace(/\{(\w+)\}/g, function (m, x) { return v && v[x] != null ? v[x] : m; }); }
  function msg(text) {
    if (lang !== "ar") return text;
    for (var i = 0; i < PAT.length; i++) if (PAT[i][0].test(text)) return text.replace(PAT[i][0], PAT[i][1]);
    return text;
  }
  function say(k, v, bad) {
    lastSay = [k, v, bad]; statusEl.textContent = k ? (T.en[k] ? tr(k, v) : msg(k)) : ""; statusEl.className = bad ? "err" : "";
  }
  function apply() {
    document.documentElement.lang = lang; document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.querySelectorAll("[data-i18n]").forEach(function (e) {
      var k = e.getAttribute("data-i18n"); if (!(k === "choose" && fileInput.files[0])) e.textContent = tr(k);
    });
    $("lang").textContent = lang === "ar" ? "English" : "العربية";
    if (lastSay) say.apply(null, lastSay);
    if (lastResult) show(lastResult, true);
  }
  $("lang").addEventListener("click", function () {
    lang = lang === "ar" ? "en" : "ar"; try { localStorage.setItem("lang", lang); } catch (e) {} apply();
  });


  /* ---------- 3D background: a slowly turning network of nodes ---------- */
  var bg = $("bg"), g = bg.getContext("2d"), W, H, dpr, nodes = [], t = 0;
  for (var i = 0; i < 80; i++) {
    var a = Math.random() * 6.283, b = Math.acos(2 * Math.random() - 1), r = 0.55 + Math.random() * 0.45;
    nodes.push([r * Math.sin(b) * Math.cos(a), r * Math.cos(b), r * Math.sin(b) * Math.sin(a)]);
  }
  function resize() {
    dpr = window.devicePixelRatio || 1; W = innerWidth; H = innerHeight;
    bg.width = W * dpr; bg.height = H * dpr; g.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function frame() {
    g.clearRect(0, 0, W, H);
    var s = Math.min(W, H) * 0.62, cx = W * (lang === "ar" ? 0.28 : 0.72), cy = H * 0.42, ca = Math.cos(t), sa = Math.sin(t), cb = Math.cos(0.4), sb = Math.sin(0.4), p = [];
    nodes.forEach(function (n) {
      var x = n[0] * ca - n[2] * sa, z = n[0] * sa + n[2] * ca, y = n[1] * cb - z * sb; z = n[1] * sb + z * cb;
      var k = 2.4 / (2.4 + z); p.push([cx + x * s * k, cy + y * s * k, k, x, y, z]);
    });
    for (var i = 0; i < p.length; i++) for (var j = i + 1; j < p.length; j++) {
      var d = Math.hypot(p[i][3] - p[j][3], p[i][4] - p[j][4], p[i][5] - p[j][5]);
      if (d < 0.42) { g.strokeStyle = "rgba(168,85,247," + (0.28 * (1 - d / 0.42) * p[i][2]) + ")"; g.beginPath(); g.moveTo(p[i][0], p[i][1]); g.lineTo(p[j][0], p[j][1]); g.stroke(); }
    }
    p.forEach(function (q) { g.fillStyle = "rgba(196,161,255," + Math.min(1, q[2] * 0.7) + ")"; g.beginPath(); g.arc(q[0], q[1], 1 + q[2] * 1.6, 0, 6.283); g.fill(); });
    t += 0.0035;
    if (!reduce) requestAnimationFrame(frame);
  }
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  addEventListener("resize", function () { resize(); if (reduce) frame(); });
  resize(); frame();

  /* ---------- helpers ---------- */
  function api(path, form) {
    return fetch(cfg.API_URL + path, { method: "POST", body: form }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok || j.error) throw new Error(j.error || tr("failed") + " (" + r.status + ")");
        return j;
      });
    });
  }
  function num(v, d) { return v == null ? "-" : Number(v).toLocaleString("en-US", { maximumFractionDigits: d == null ? 1 : d }); }
  function el(tag, text, cls) { var e = document.createElement(tag); e.textContent = text; if (cls) e.className = cls; return e; }

  /* ---------- optional captcha (Cloudflare Turnstile) ---------- */
  if (cfg.TURNSTILE_SITE_KEY) {
    var sc = document.createElement("script");
    sc.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"; sc.async = true;
    sc.onload = function () { turnstile.render("#captcha", { sitekey: cfg.TURNSTILE_SITE_KEY, theme: "dark", callback: function (tk) { captchaToken = tk; } }); };
    document.head.appendChild(sc);
  }

  /* ---------- step 1: choose a file ---------- */
  fileInput.addEventListener("change", function () {
    var f = fileInput.files[0]; $("results").hidden = true; $("step2").hidden = true;
    if (!f) return;
    $("fname").textContent = f.name;
    if (!/\.csv$/i.test(f.name)) return say("needCsv", null, true);
    if (f.size > 10 * 1024 * 1024) return say("tooBig", null, true);
    say("reading");
    var fd = new FormData(); fd.append("file", f);
    api("/inspect", fd).then(function (info) {
      var sel = $("target"); sel.textContent = "";
      info.numeric_columns.forEach(function (c) { var o = document.createElement("option"); o.value = c; o.textContent = c; sel.appendChild(o); });
      if (!info.numeric_columns.length) return say("noNum", null, true);
      $("step2").hidden = false;
      say(info.date_column ? "foundDate" : "noDate", { rows: info.rows, col: info.date_column });
    }).catch(function (e) { say(e.message, null, true); });
  });

  /* ---------- step 2: analyze ---------- */
  $("go").addEventListener("click", function () {
    var f = fileInput.files[0]; if (!f) return;
    var fd = new FormData(); fd.append("file", f); lastTarget = $("target").value; fd.append("target", lastTarget); fd.append("task", document.querySelector('input[name="task"]:checked').value); fd.append("captcha_token", captchaToken);
    $("go").disabled = true; say("analyzing");
    api("/analyze", fd).then(function (r) { say(""); show(r); })
      .catch(function (e) { say(e.message, null, true); })
      .then(function () { $("go").disabled = false; if (window.turnstile && cfg.TURNSTILE_SITE_KEY) { captchaToken = ""; turnstile.reset(); } });
  });

  /* ---------- results ---------- */
  var NAMES = {
    "Chronos-2": ["AI model (Chronos-2)", "نموذج ذكاء اصطناعي (Chronos-2)"],
    "Prophet multiplicative": ["Prophet (seasons grow with the trend)", "Prophet (المواسم تكبر مع النمو)"],
    "Prophet additive": ["Prophet (fixed seasons)", "Prophet (مواسم ثابتة)"],
    "Seasonal naive": ["Repeat the last pattern", "تكرار آخر نمط"],
    "Average (baseline)": ["Always the average", "المتوسط دائمًا"],
    "Linear Regression": ["Straight-line model", "نموذج الخط المستقيم"],
    "Random Forest": ["Random Forest (many trees)", "Random Forest (غابة أشجار)"],
    "Gradient Boosting": ["Gradient Boosting (smart trees)", "Gradient Boosting (أشجار ذكية)"]
  };
  var UNIT = { D: ["days", "يوم"], W: ["weeks", "أسبوع"], M: ["months", "أشهر"] };
  var CYC = { D: ["days", "يومًا"], W: ["weeks", "أسبوعًا"], M: ["months", "شهرًا"] };
  function nm(k) { return NAMES[k] ? NAMES[k][lang === "ar" ? 1 : 0] : k; }
  function plain(r) {
    var acc = r.error_percent != null ? tr("acc", { e: num(r.error_percent) }) : "";
    if (r.mode !== "time series") {
      var k = Object.keys(r.importance)[0];
      return tr("topFactor", { k: k, p: num(r.importance[k] * 100, 0) }) + " " + acc +
        (r.predictions && r.predictions.length ? " " + tr("predRows", { n: r.predictions.length }) : "");
    }
    var n = r.horizon, f = r.forecast, h = r.history.slice(-n), u = (UNIT[r.freq[0]] || ["periods", "فترة"])[lang === "ar" ? 1 : 0];
    var avgF = f.reduce(function (a, p) { return a + p.yhat; }, 0) / f.length, avgH = h.reduce(function (a, p) { return a + p.value; }, 0) / h.length;
    var top = f.reduce(function (a, p) { return p.yhat > a.yhat ? p : a; }, f[0]), pct = avgH ? (avgF / avgH - 1) * 100 : 0;
    return tr("tsPlain", { n: n, u: u, avg: num(avgF, 0), dir: tr(pct >= 0 ? "up" : "down"), pct: num(Math.abs(pct)), top: num(top.yhat, 0), date: top.date }) + " " + acc;
  }
  function csvCell(v) {
    var s = v == null ? "" : String(v);
    if (typeof v === "string" && /^[=+\-@\t\r]/.test(s)) s = "'" + s;   // stops spreadsheet formula injection
    return '"' + s.replace(/"/g, '""') + '"';
  }
  function download(r) {
    var rows, cols;
    if (r.mode === "time series") rows = [["date", "forecast", "low", "high"]].concat(r.forecast.map(function (p) { return [p.date, p.yhat, p.lower, p.upper]; }));
    else if (r.predictions && r.predictions.length) { cols = Object.keys(r.predictions[0]); rows = [cols].concat(r.predictions.map(function (p) { return cols.map(function (c) { return p[c]; }); })); }
    else return;
    var blob = new Blob(["\ufeff" + rows.map(function (x) { return x.map(csvCell).join(","); }).join("\n")], { type: "text/csv" });
    var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "evolvia-forecast.csv"; a.click(); URL.revokeObjectURL(a.href);
  }
  function show(r, quiet) {
    lastResult = r;
    var ts = r.mode === "time series" && !!r.forecast, fc = !!r.best;
    $("results").hidden = false;
    $("summary").textContent = tr(r.task === "analysis" ? "readyA" : "ready", { col: lastTarget });
    $("plain").textContent = fc ? plain(r) : "";
    var ul = $("notes"); ul.textContent = ""; (r.notes || []).forEach(function (n) { ul.appendChild(el("li", msg(n))); });
    var bars = $("bars"); bars.textContent = "";
    $("chart").hidden = !ts; $("legend").hidden = !ts; $("cap").hidden = !ts; $("preds").hidden = true;
    $("dl").hidden = !(ts || (r.predictions && r.predictions.length));
    if (ts) chart(r); else if (fc) importance(r, bars);
    var cmp = $("cmp"); cmp.textContent = "";
    cmp.appendChild(el("p", tr("cmpNote") + " " + nm(r.best || ""), "cap"));
    var max = fc ? Math.max.apply(null, Object.values(r.scores)) : 1; $("moreBox").hidden = !fc;
    Object.keys(r.scores || {}).forEach(function (k) { bar(cmp, nm(k), r.scores[k] / max, num(r.scores[k], 0)); });
    $("dl").onclick = function () { download(r); };
    analysisView(r);
    if (!quiet) $("results").scrollIntoView({ behavior: "smooth" });
  }
  var WD = [["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], ["الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"]];
  var MO = [["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]];
  function sect(box, title) { box.appendChild(el("h4", title)); }
  function analysisView(r) {
    var box = $("ana"), a = r.analysis; box.textContent = ""; box.hidden = !a;
    if (!a) return;
    var li = lang === "ar" ? 1 : 0, s = a.stats;
    sect(box, tr("aTitle"));
    var st = el("div", "", "stats");
    [["aAvg", s.mean], ["aMid", s.median], ["aLow", s.min], ["aHigh", s.max], ["aRows", a.quality.rows]].forEach(function (p) {
      var d = document.createElement("div"); d.appendChild(el("b", num(p[1], 0))); d.appendChild(el("span", tr(p[0]))); st.appendChild(d);
    });
    box.appendChild(st);
    if (a.trend) {
      var t = a.trend, txt = tr("trend_" + t.direction, { g: num(Math.abs(t.growth_percent || 0)) });
      if (t.recent_change_percent != null) txt += " " + tr("trendRecent", { k: t.cycle, u: (CYC[t.unit] || ["periods", "فترة"])[li], c: num(t.recent_change_percent) });
      box.appendChild(el("p", txt, "plainp"));
    }
    (a.profiles || []).forEach(function (p) {
      var wd = p.name === "weekday", names = wd ? WD[li] : MO[li], max = Math.max.apply(null, p.index);
      sect(box, tr(wd ? "pWeekday" : "pMonth"));
      p.index.forEach(function (v, i) { bar(box, names[wd ? p.keys[i] : p.keys[i] - 1], v / max, Math.round(v * 100)); });
    });
    if (a.extremes) {
      var hi = a.extremes.highest[0], lo = a.extremes.lowest[0];
      box.appendChild(el("p", tr("ext", { hi: num(hi.value, 0), hd: hi.date, lo: num(lo.value, 0), ld: lo.date }), "plainp"));
    }
    if (a.anomalies) {
      sect(box, tr("anTitle"));
      if (!a.anomalies.length) box.appendChild(el("p", tr("anNone"), "plainp"));
      else {
        var ul = document.createElement("ul");
        a.anomalies.forEach(function (x) { ul.appendChild(el("li", tr("anItem", { d: x.date, v: num(x.value, 0), e: num(x.expected, 0) }))); });
        box.appendChild(ul);
      }
    }
    if (a.correlations && a.correlations.length) {
      sect(box, tr("corrTitle"));
      a.correlations.forEach(function (c) { bar(box, c.column, Math.abs(c.value), (c.value > 0 ? "+" : "") + c.value); });
      box.appendChild(el("p", tr("corrNote"), "cap"));
    }
    if (a.histogram) {
      var hg = a.histogram, hm = Math.max.apply(null, hg.counts), step = (hg.high - hg.low) / hg.counts.length;
      sect(box, tr("distTitle"));
      hg.counts.forEach(function (n, i) { bar(box, num(hg.low + step * i, 0) + " - " + num(hg.low + step * (i + 1), 0), n / hm, n); });
      box.appendChild(el("p", tr("outl", { n: a.outliers }), "cap"));
    }
  }
  function bar(box, label, frac, val) {
    var row = el("div", "", "bar"), i = document.createElement("i");
    i.style.width = Math.max(2, frac * 100) + "%";
    row.appendChild(el("span", label)); var w = document.createElement("div"); w.appendChild(i); row.appendChild(w); row.appendChild(el("b", val)); box.appendChild(row);
  }
  function importance(r, box) {
    box.appendChild(el("h4", tr("matters")));
    Object.keys(r.importance).slice(0, 7).forEach(function (k) { bar(box, k, r.importance[k], num(r.importance[k] * 100, 0) + "%"); });
    if (r.predictions && r.predictions.length) {
      var tb = $("preds"); tb.hidden = false; tb.textContent = "";
      var cols = Object.keys(r.predictions[0]), hr = document.createElement("tr");
      cols.forEach(function (c) { hr.appendChild(el("th", c)); }); tb.appendChild(hr);
      r.predictions.slice(0, 10).forEach(function (row) {
        var tr = document.createElement("tr"); cols.forEach(function (c) { tr.appendChild(el("td", row[c] == null ? "" : String(row[c]))); }); tb.appendChild(tr);
      });
    }
  }
  function chart(r) {
    var c = $("chart"), x = c.getContext("2d"), w = c.width, h = c.height, pad = 46;
    var hist = r.history.slice(-Math.max(60, r.horizon * 2)), fc = r.forecast, all = hist.length + fc.length;
    var vals = hist.map(function (p) { return p.value; }).concat(fc.map(function (p) { return p.upper == null ? p.yhat : p.upper; }), fc.map(function (p) { return p.lower == null ? p.yhat : p.lower; }));
    var lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals), span = (hi - lo) || 1;
    var X = function (i) { return pad + i * (w - pad - 12) / (all - 1); }, Y = function (v) { return h - 30 - (v - lo) / span * (h - 50); };
    x.clearRect(0, 0, w, h); x.font = "12px system-ui"; x.fillStyle = "#a794c9"; x.strokeStyle = "rgba(124,58,237,.25)"; x.fillText(lastTarget, pad, 12);
    for (var k = 0; k <= 4; k++) { var v = lo + span * k / 4, y = Y(v); x.beginPath(); x.moveTo(pad, y); x.lineTo(w - 8, y); x.stroke(); x.fillText(num(v, 0), 2, y + 4); }
    x.fillText(hist[0].date, pad, h - 8); x.fillText(fc[fc.length - 1].date, w - 90, h - 8);
    x.strokeStyle = "#c4a1ff"; x.lineWidth = 2; x.beginPath();
    hist.forEach(function (p, i) { i ? x.lineTo(X(i), Y(p.value)) : x.moveTo(X(i), Y(p.value)); }); x.stroke();
    var o = hist.length - 1;
    if (fc[0].lower != null) {
      x.fillStyle = "rgba(168,85,247,.28)"; x.beginPath();
      fc.forEach(function (p, i) { i ? x.lineTo(X(o + 1 + i), Y(p.upper)) : x.moveTo(X(o + 1), Y(p.upper)); });
      for (var j = fc.length - 1; j >= 0; j--) x.lineTo(X(o + 1 + j), Y(fc[j].lower));
      x.closePath(); x.fill();
    }
    x.strokeStyle = "#a855f7"; x.setLineDash([6, 4]); x.beginPath(); x.moveTo(X(o), Y(hist[o].value));
    fc.forEach(function (p, i) { x.lineTo(X(o + 1 + i), Y(p.yhat)); }); x.stroke();
    x.strokeStyle = "rgba(196,161,255,.5)"; x.setLineDash([2, 4]); x.beginPath(); x.moveTo(X(o + 0.5), 18); x.lineTo(X(o + 0.5), h - 30); x.stroke(); x.setLineDash([]);
    x.fillStyle = "#c4a1ff"; x.fillText(tr("lgFc"), X(o + 0.5) + 6, 30);
  }
  apply();
})();
