# Evolvia Nexus

Upload a CSV of numbers and get an analysis, a forecast, or both. The app picks the best model automatically.

- Data with dates: forecasts with a likely range. It compares Chronos-2, Prophet and a simple baseline, and keeps the one with the smallest error.
- Other tables: finds which columns matter most and predicts empty values.
- Plain-language results in English and Arabic.

## Run locally

Backend (Python 3.11+):

    cd backend
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    ALLOWED_ORIGINS=http://localhost:5173,http://127.0.0.1:5173 uvicorn main:app --port 8000

Frontend:

    cd frontend
    python3 -m http.server 5173 --bind 127.0.0.1

Then open http://127.0.0.1:5173

## Status

Early prototype. Do not use it with sensitive data yet: login, a privacy policy and a full security review are still to come.
