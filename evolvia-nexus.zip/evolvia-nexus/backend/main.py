"""
main.py - the web API. The frontend talks to these endpoints.

Run it with:   uvicorn main:app --port 8000
"""
import hashlib
import io
import logging
import threading
import time

import pandas as pd
from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from analyzer import auto_analyze, clean, inspect_data, result_to_json
from limits import RateLimiter, settings
from safety import clean_text, validate_output, verify_captcha

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("api")

# The automatic documentation pages are only available when DEBUG=1
app = FastAPI(
    title="Forecasting SaaS",
    docs_url="/docs" if settings.debug else None,
    redoc_url=None,
    openapi_url="/openapi.json" if settings.debug else None,
)

# Only the websites listed in ALLOWED_ORIGINS may call this API from a browser.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)

SECURITY_HEADERS = {
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",
    "Cache-Control": "no-store",
}


@app.middleware("http")
async def protect(request: Request, call_next):
    # refuse huge uploads before reading them at all
    size = request.headers.get("content-length", "")
    limit = settings.max_file_mb * 1024 * 1024 + 100_000
    if size.isdigit() and int(size) > limit:
        response = JSONResponse(status_code=413, content={"error": "Request is too large."})
    else:
        response = await call_next(request)
    for name, value in SECURITY_HEADERS.items():
        response.headers[name] = value
    return response

limiter = RateLimiter()
analysis_slots = threading.BoundedSemaphore(settings.max_parallel)


def client_ip(request):
    if settings.trust_proxy:
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def anonymous(ip):
    """We never write a real IP address in the logs, only a short fingerprint."""
    return hashlib.sha256(ip.encode()).hexdigest()[:10]


def fail(status, message):
    return JSONResponse(status_code=status, content={"error": message})


# Details of any error go to OUR log only. The user gets a short, generic message.
@app.exception_handler(RequestValidationError)
async def invalid_request(request: Request, exc: RequestValidationError):
    return fail(400, "The request is missing something or is not valid.")


@app.exception_handler(Exception)
async def unexpected_error(request: Request, exc: Exception):
    log.exception("unhandled error")
    return fail(500, "Something went wrong on our side.")


def read_csv(raw_bytes):
    """Try a few encodings, so Arabic files saved from Excel also open."""
    for encoding in ["utf-8-sig", "cp1256", "latin-1"]:
        try:
            return pd.read_csv(io.BytesIO(raw_bytes), encoding=encoding)
        except Exception:
            continue
    return None


def load_table(file):
    """Read the upload safely. Returns (table, None) or (None, error response)."""
    max_bytes = settings.max_file_mb * 1024 * 1024
    raw = file.file.read(max_bytes + 1)
    if len(raw) > max_bytes:
        return None, fail(413, f"File is too large (max {settings.max_file_mb} MB).")

    data = read_csv(raw)
    if data is None or data.empty:
        return None, fail(400, "Could not read the file as a CSV table.")
    if len(data) > settings.max_rows:
        return None, fail(413, f"Too many rows (max {settings.max_rows}).")
    return data, None


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/inspect")
def inspect(request: Request, file: UploadFile = File(...)):
    ip = client_ip(request)
    if not limiter.allow(f"min:{ip}", settings.per_minute, 60):
        return fail(429, "Too many requests. Please wait a minute.")

    data, problem = load_table(file)
    if problem:
        return problem

    log.info("inspect who=%s rows=%d", anonymous(ip), len(data))
    return clean(inspect_data(data))


@app.post("/analyze")
def analyze(
    request: Request,
    file: UploadFile = File(...),
    target: str = Form(...),
    mode: str = Form("auto"),
    task: str = Form("both"),
    captcha_token: str = Form(""),
):
    ip = client_ip(request)
    who = anonymous(ip)
    target = clean_text(target, 100)
    if mode not in ("auto", "time series", "regression"):
        return fail(400, "mode must be 'auto', 'time series' or 'regression'.")
    if task not in ("analysis", "forecast", "both"):
        return fail(400, "task must be 'analysis', 'forecast' or 'both'.")

    if not limiter.allow(f"min:{ip}", settings.per_minute, 60):
        return fail(429, "Too many requests. Please wait a minute.")
    if not limiter.allow(f"day:{ip}", settings.analyses_per_day, 86400):
        return fail(429, "Daily analysis limit reached. Please try again tomorrow.")

    if settings.turnstile_secret and not verify_captcha(
        captcha_token, ip, settings.turnstile_secret
    ):
        return fail(400, "Captcha check failed. Please try again.")

    data, problem = load_table(file)
    if problem:
        return problem

    if not analysis_slots.acquire(timeout=2):
        return fail(503, "The server is busy with other analyses. Please try again in a minute.")

    started = time.time()
    try:
        result = auto_analyze(data, target, mode, task)
    except Exception:
        log.exception("analysis crashed who=%s rows=%d", who, len(data))
        return fail(500, "Something went wrong while analyzing your data.")
    finally:
        analysis_slots.release()

    seconds = round(time.time() - started, 1)
    if "error" in result:
        log.info("analyze rejected who=%s rows=%d reason=%s", who, len(data), result["error"])
        return fail(400, result["error"])

    log.info(
        "analyze ok who=%s rows=%d mode=%s best=%s seconds=%s",
        who, len(data), result["mode"], result.get("best"), seconds,
    )
    try:
        return validate_output(result_to_json(result))
    except ValueError:
        log.exception("output validation failed who=%s", who)
        return fail(500, "Something went wrong on our side.")
