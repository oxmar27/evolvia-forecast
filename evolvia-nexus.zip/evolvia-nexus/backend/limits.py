"""
limits.py - settings read from environment variables + a simple rate limiter.

Nothing secret is written in the code: every value can be changed from outside
(an .env file, or the hosting platform's settings) without touching the code.
"""
import os
import threading
import time
from collections import defaultdict, deque


def env_int(name, default):
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


class Settings:
    # safe default: only a website running on your own computer may call the API
    allowed_origins = [
        o.strip()
        for o in os.getenv(
            "ALLOWED_ORIGINS",
            "http://localhost:3000,http://localhost:5173,http://localhost:8080,http://127.0.0.1:5500",
        ).split(",")
        if o.strip()
    ]
    max_file_mb = env_int("MAX_FILE_MB", 10)
    max_rows = env_int("MAX_ROWS", 50000)
    per_minute = env_int("RATE_PER_MINUTE", 20)
    analyses_per_day = env_int("ANALYSES_PER_DAY", 30)
    max_parallel = env_int("MAX_PARALLEL_ANALYSES", 1)
    trust_proxy = os.getenv("TRUST_PROXY", "0") == "1"
    debug = os.getenv("DEBUG", "0") == "1"
    turnstile_secret = os.getenv("TURNSTILE_SECRET", "")


settings = Settings()


class RateLimiter:
    """Counts requests per key (for example per visitor) inside a time window.

    It lives in memory, so it works for ONE server process and resets when the
    server restarts. When we run several servers, we move it to Redis.
    """

    def __init__(self):
        self.hits = defaultdict(deque)
        self.lock = threading.Lock()
        self.calls = 0

    def allow(self, key, limit, window_seconds):
        now = time.time()
        with self.lock:
            self.calls += 1
            if self.calls % 1000 == 0:
                self._cleanup(now)

            q = self.hits[key]
            while q and q[0] <= now - window_seconds:
                q.popleft()
            if len(q) >= limit:
                return False
            q.append(now)
            return True

    def _cleanup(self, now):
        old_keys = [k for k, q in self.hits.items() if not q or q[-1] < now - 86400]
        for k in old_keys:
            del self.hits[k]
