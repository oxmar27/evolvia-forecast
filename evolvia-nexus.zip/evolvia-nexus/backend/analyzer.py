"""
analyzer.py - the brain of the SaaS.

Takes a table + the name of a numeric column to predict and returns:
  - time series mode: a forecast with a likely range
  - regression mode : model accuracy, important columns, and predictions
                      for rows where the target is empty
"""
import logging

import numpy as np
import pandas as pd
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline

logging.getLogger("prophet").setLevel(logging.WARNING)
logging.getLogger("cmdstanpy").setLevel(logging.WARNING)

try:
    from prophet import Prophet
except ImportError:
    Prophet = None

_chronos = None
_chronos_failed = False


def get_chronos():
    """Load the pretrained Chronos-2 model once, and reuse it."""
    global _chronos, _chronos_failed
    if _chronos_failed:
        return None
    if _chronos is None:
        try:
            import torch
            from chronos import Chronos2Pipeline

            device = "cuda" if torch.cuda.is_available() else "cpu"
            _chronos = Chronos2Pipeline.from_pretrained(
                "amazon/chronos-2", device_map=device
            )
        except Exception as e:
            print("Chronos-2 not available:", e)
            _chronos_failed = True
            return None
    return _chronos


# ---------------------------------------------------------------- helpers
def mae(actual, predicted):
    return np.mean(np.abs(np.asarray(actual) - np.asarray(predicted)))


def find_date_column(data):
    for col in data.columns:
        if pd.api.types.is_datetime64_any_dtype(data[col]):
            return col

    for col in data.columns:
        if not pd.api.types.is_numeric_dtype(data[col]):
            try:
                pd.to_datetime(data[col])
                return col
            except Exception:
                pass

    return None


def clean(value):
    """Turn numpy / pandas values into plain Python so they can become JSON."""
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if value is pd.NaT:
        return None
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


# ---------------------------------------------------------- inspect a file
def inspect_data(data):
    date_col = find_date_column(data)
    numeric = [c for c in data.columns if pd.api.types.is_numeric_dtype(data[c])]
    return {
        "rows": len(data),
        "columns": list(data.columns),
        "numeric_columns": numeric,
        "date_column": date_col,
        "suggested_mode": "time series" if date_col else "regression",
        "preview": data.head(5).astype(object).where(data.head(5).notna(), None)
        .to_dict(orient="records"),
    }



# ---------------------------------------------------------- data description
CYCLE = {"D": 365, "W": 52, "M": 12}


def top_correlations(data, target, limit=5):
    nums = data.select_dtypes(include="number")
    if target not in nums or nums.shape[1] < 2 or len(nums) < 30:
        return []
    c = nums.corr()[target].drop(target).dropna()
    c = c.reindex(c.abs().sort_values(ascending=False).index)[:limit]
    return [{"column": str(k), "value": round(float(v), 2)} for k, v in c.items()]


def describe_series(series, freq, season, data, target):
    """Explain a time series in plain facts: level, trend, patterns, odd values."""
    n = len(series)
    stats = {"mean": series.mean(), "median": series.median(), "min": series.min(), "max": series.max()}

    slope, intercept = np.polyfit(np.arange(n), series.values, 1)
    start, end = intercept, intercept + slope * (n - 1)
    growth = (end - start) / abs(start) * 100 if start else None
    direction = "flat" if growth is None or abs(growth) < 2 else ("up" if growth > 0 else "down")
    k = CYCLE.get(freq[0], 0)
    recent = None
    if k and n >= 2 * k and series.iloc[-2 * k:-k].mean() != 0:
        recent = (series.iloc[-k:].mean() / series.iloc[-2 * k:-k].mean() - 1) * 100
    trend = {"direction": direction, "growth_percent": growth, "recent_change_percent": recent, "cycle": k, "unit": freq[0]}

    # typical pattern: each value divided by its moving average, then averaged per weekday / month
    profiles = []

    def profile(name, groups, window):
        if n < 2 * window:
            return
        ratio = series / series.rolling(window, center=True, min_periods=window).mean()
        g = ratio.groupby(groups).mean().dropna()
        if len(g) >= 3:
            profiles.append({"name": name, "keys": [int(i) for i in g.index],
                             "index": [round(float(v), 3) for v in g.values]})

    if freq[0] == "D":
        profile("weekday", series.index.dayofweek, 7)
        profile("month", series.index.month, 365)
    elif freq[0] == "W":
        profile("month", series.index.month, 52)
    elif freq[0] == "M":
        profile("month", series.index.month, 12)

    # unusual values: far away from the local middle value
    w = season if season > 1 else 7
    base = series.rolling(w, center=True, min_periods=1).median()
    resid = series - base
    mad = (resid - resid.median()).abs().median() * 1.4826
    anomalies = []
    if mad > 0:
        z = (resid - resid.median()).abs() / mad
        for d in z[z > 6].sort_values(ascending=False).index[:5]:
            anomalies.append({"date": d, "value": float(series[d]), "expected": float(base[d])})

    def points(s):
        return [{"date": d, "value": float(v)} for d, v in s.items()]

    return {
        "stats": stats,
        "quality": {"rows": len(data), "periods": n,
                    "missing_percent": round(100 * float(data[target].isnull().mean()), 1)},
        "trend": trend, "profiles": profiles,
        "extremes": {"highest": points(series.nlargest(3)), "lowest": points(series.nsmallest(3))},
        "anomalies": anomalies, "correlations": top_correlations(data, target),
    }


def describe_table(data, target):
    s = data[target].dropna()
    q1, q3 = s.quantile([0.25, 0.75])
    iqr = q3 - q1
    outliers = int(((s < q1 - 3 * iqr) | (s > q3 + 3 * iqr)).sum()) if iqr > 0 else 0
    counts, _ = np.histogram(s, bins=10)
    return {
        "stats": {"mean": s.mean(), "median": s.median(), "min": s.min(), "max": s.max()},
        "quality": {"rows": len(data), "missing_percent": round(100 * float(data[target].isnull().mean()), 1)},
        "outliers": outliers,
        "histogram": {"counts": [int(c) for c in counts], "low": float(s.min()), "high": float(s.max())},
        "correlations": top_correlations(data, target),
    }


# ------------------------------------------------------------ time series
FREQ_SETTINGS = {"D": (7, 90), "W": (52, 12), "M": (12, 6)}


def get_settings(freq, length):
    season, horizon = FREQ_SETTINGS.get(freq[0], (1, max(min(length // 10, 365), 1)))
    return season, horizon


def guess_freq(index):
    freq = pd.infer_freq(index)
    if freq is not None:
        return freq

    step = index.to_series().diff().dropna().mode()[0]
    days = step.days
    if days == 1:
        return "D"
    if days == 7:
        return "W-" + index[0].strftime("%a").upper()
    if 28 <= days <= 31 and index.is_month_start.all():
        return "MS"
    return None


def prepare_series(series):
    notes = []
    series = series.groupby(level=0).mean()

    freq = guess_freq(series.index)
    if freq is None:
        return None, None, ["Could not figure out the date frequency."]

    series = series.asfreq(freq)
    missing = int(series.isnull().sum())
    if missing > 0:
        if missing / len(series) > 0.1:
            return None, None, [f"Too many missing values ({missing} of {len(series)})."]
        series = series.interpolate().bfill()
        notes.append(f"Filled {missing} missing values by interpolation.")

    return series, freq, notes


def forecast_seasonal_naive(train, n, freq, season):
    pattern = train.iloc[-season:].values
    values = np.tile(pattern, n // season + 1)[:n]
    return pd.DataFrame({"yhat": values})


def forecast_prophet(train, n, freq, mode):
    d = train.reset_index()
    d.columns = ["ds", "y"]
    m = Prophet(seasonality_mode=mode)
    m.fit(d)
    out = m.predict(m.make_future_dataframe(periods=n, freq=freq)).iloc[-n:]
    return pd.DataFrame(
        {
            "yhat": out["yhat"].values,
            "lower": out["yhat_lower"].values,
            "upper": out["yhat_upper"].values,
        }
    )


def forecast_chronos(train, n):
    ctx = train.reset_index()
    ctx.columns = ["timestamp", "target"]
    ctx["id"] = "series"
    out = get_chronos().predict_df(
        ctx,
        prediction_length=n,
        quantile_levels=[0.1, 0.5, 0.9],
        id_column="id",
        timestamp_column="timestamp",
        target="target",
    )
    return pd.DataFrame(
        {
            "yhat": out["0.5"].values,
            "lower": out["0.1"].values,
            "upper": out["0.9"].values,
        }
    )


def get_methods(n, freq, season):
    methods = {
        "Seasonal naive": lambda tr: forecast_seasonal_naive(tr, n, freq, season)
    }
    skipped = []

    if Prophet is not None:
        methods["Prophet additive"] = lambda tr: forecast_prophet(tr, n, freq, "additive")
        methods["Prophet multiplicative"] = lambda tr: forecast_prophet(
            tr, n, freq, "multiplicative"
        )
    else:
        skipped += ["Prophet additive", "Prophet multiplicative"]

    if get_chronos() is not None:
        methods["Chronos-2"] = lambda tr: forecast_chronos(tr, n)
    else:
        skipped.append("Chronos-2")

    return methods, skipped


def analyze_time_series(data, target, task="both"):
    date_col = find_date_column(data)
    series = data[[date_col, target]].copy()
    series[date_col] = pd.to_datetime(series[date_col])
    series = series.sort_values(date_col).set_index(date_col)[target]

    series, freq, notes = prepare_series(series)
    if series is None:
        return {"error": notes[0]}

    season, n = get_settings(freq, len(series))
    if len(series) < season * 3:
        notes.append(
            "Short history (less than 3 full seasonal cycles): "
            "forecasts may be less reliable."
        )
    analysis = None
    if task in ("analysis", "both"):
        analysis = describe_series(series, freq, season, data, target)
    if task == "analysis":
        return {"mode": "time series", "task": task, "notes": notes, "analysis": analysis}

    methods, skipped = get_methods(n, freq, season)
    if skipped:
        notes.append("Methods not available on this server: " + ", ".join(skipped))

    windows = 3 if len(series) >= n * 4 else 1
    rows = []
    for k in range(windows):
        cut = len(series) - n * (k + 1)
        train, test = series.iloc[:cut], series.iloc[cut:cut + n]
        row = {}
        for name, fn in methods.items():
            row[name] = mae(test, fn(train)["yhat"].values)
        rows.append(row)

    scores = pd.DataFrame(rows).mean().sort_values()
    best_name = scores.index[0]

    forecast = methods[best_name](series)
    forecast.index = pd.date_range(series.index[-1], periods=n + 1, freq=freq)[1:]

    level = series.mean()
    error_percent = scores.iloc[0] / level * 100 if level != 0 else None

    return {
        "mode": "time series",
        "task": task,
        "analysis": analysis,
        "freq": freq,
        "horizon": n,
        "windows": windows,
        "scores": scores,
        "best": best_name,
        "error_percent": error_percent,
        "forecast": forecast,
        "history": series,
        "notes": notes,
    }


# ------------------------------------------------------------- regression
def analyze_regression(data, target, task="both"):
    all_rows = data
    data = data.dropna(subset=[target])
    if len(data) < 30:
        return {"error": "Not enough rows (need at least 30)."}

    X = data.drop(columns=[target])
    y = data[target]
    numeric_cols = X.select_dtypes(include="number").columns.tolist()
    dropped = [c for c in X.columns if c not in numeric_cols]
    X = X[numeric_cols]
    if X.shape[1] == 0:
        return {"error": "No numeric feature columns to learn from."}

    notes = []
    if dropped:
        notes.append("Ignored non-numeric columns: " + ", ".join(map(str, dropped)))
    if len(data) < 100:
        notes.append("Small dataset (under 100 rows): results may be unstable.")

    analysis = describe_table(all_rows, target) if task in ("analysis", "both") else None
    if task == "analysis":
        return {"mode": "regression", "task": task, "notes": notes, "analysis": analysis}

    models = {
        "Average (baseline)": DummyRegressor(strategy="mean"),
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(n_estimators=200, random_state=42),
        "Gradient Boosting": GradientBoostingRegressor(random_state=42),
    }
    scores = {}
    for name, model in models.items():
        pipe = make_pipeline(SimpleImputer(strategy="median"), model)
        s = cross_val_score(pipe, X, y, cv=5, scoring="neg_mean_absolute_error")
        scores[name] = -s.mean()
    scores = pd.Series(scores).sort_values()
    best_name = scores.index[0]

    best_model = make_pipeline(SimpleImputer(strategy="median"), models[best_name])
    best_model.fit(X, y)

    imp = permutation_importance(
        best_model, X, y, n_repeats=5, random_state=42,
        scoring="neg_mean_absolute_error",
    )
    importance = pd.Series(imp.importances_mean, index=X.columns).clip(lower=0)
    if importance.sum() > 0:
        importance = importance / importance.sum()
    importance = importance.sort_values(ascending=False)

    # rows where the target is empty = rows the user wants us to predict
    unknown = all_rows[all_rows[target].isnull()]
    predictions = None
    if len(unknown) > 0:
        predicted = best_model.predict(unknown[numeric_cols])
        predictions = unknown.copy()
        predictions["predicted_" + str(target)] = predicted

    return {
        "mode": "regression",
        "task": task,
        "analysis": analysis,
        "scores": scores,
        "best": best_name,
        "error_percent": scores.iloc[0] / y.mean() * 100 if y.mean() != 0 else None,
        "importance": importance,
        "dropped_columns": dropped,
        "features": numeric_cols,
        "predictions": predictions,
        "notes": notes,
        "model": best_model,
    }


# ------------------------------------------------------------ entry point
def auto_analyze(data, target, mode="auto", task="both"):
    if task not in ("analysis", "forecast", "both"):
        return {"error": "task must be 'analysis', 'forecast' or 'both'."}
    if target not in data.columns:
        return {"error": f"Column '{target}' not found."}
    if not pd.api.types.is_numeric_dtype(data[target]):
        return {"error": f"Column '{target}' is not numeric."}

    has_date = find_date_column(data) is not None
    if mode == "auto":
        mode = "time series" if has_date else "regression"

    if mode == "time series":
        if not has_date:
            return {"error": "No date column found, so a time series forecast is not possible."}
        return analyze_time_series(data, target, task)
    if mode == "regression":
        return analyze_regression(data, target, task)

    return {"error": "mode must be 'auto', 'time series' or 'regression'."}


def result_to_json(result):
    """Convert the result of auto_analyze into something the frontend can read."""
    if "error" in result:
        return {"error": result["error"]}

    out = {"mode": result["mode"], "task": result["task"], "notes": result["notes"]}
    if result.get("analysis") is not None:
        out["analysis"] = clean(result["analysis"])
    if "best" not in result:
        return out

    out.update({
        "best": result["best"],
        "scores": clean(result["scores"].to_dict()),
        "error_percent": clean(result["error_percent"]),
    })

    if result["mode"] == "time series":
        history = result["history"].iloc[-500:]
        forecast = result["forecast"]
        out["freq"] = result["freq"]
        out["horizon"] = result["horizon"]
        out["history"] = [
            {"date": d, "value": v} for d, v in zip(clean(list(history.index)), clean(list(history.values)))
        ]
        has_range = "lower" in forecast.columns
        out["forecast"] = [
            {
                "date": clean(d),
                "yhat": clean(row["yhat"]),
                "lower": clean(row["lower"]) if has_range else None,
                "upper": clean(row["upper"]) if has_range else None,
            }
            for d, (_, row) in zip(forecast.index, forecast.iterrows())
        ]
    else:
        out["importance"] = clean(result["importance"].to_dict())
        out["dropped_columns"] = result["dropped_columns"]
        out["features"] = result["features"]
        preds = result["predictions"]
        if preds is not None and len(preds) > 1000:
            out["notes"] = out["notes"] + ["Showing only the first 1000 predictions."]
            preds = preds.head(1000)
        out["predictions"] = (
            None
            if preds is None
            else clean(preds.astype(object).where(preds.notna(), None).to_dict(orient="records"))
        )

    return out
