"""
safety.py - input cleaning, output validation and captcha checking.

Rule of the house: nothing that came from a user is trusted, and nothing leaves
the server before it has been checked.
"""
import json
import math
import re
import urllib.parse
import urllib.request

CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean_text(value, max_len=200):
    """Remove invisible control characters and cut the text to a safe length."""
    return CONTROL_CHARS.sub("", str(value))[:max_len]


# the most items each list in the answer may have
LIST_LIMITS = {
    "history": 500, "forecast": 1000, "predictions": 1000,
    "scores": 10, "importance": 50, "notes": 20,
}

FORECAST_KEYS = {
    "time series": ["best", "scores", "error_percent", "freq", "horizon", "history", "forecast"],
    "regression": ["best", "scores", "error_percent", "importance", "dropped_columns",
                   "features", "predictions"],
}


def _scrub(value, depth=0):
    """Walk through the answer: only plain JSON types are allowed."""
    if depth > 6:
        raise ValueError("answer is nested too deeply")
    if isinstance(value, dict):
        return {clean_text(k, 100): _scrub(v, depth + 1) for k, v in value.items()}
    if isinstance(value, list):
        return [_scrub(v, depth + 1) for v in value]
    if isinstance(value, str):
        return clean_text(value, 300)
    if isinstance(value, float):
        return float(value) if math.isfinite(value) else None
    if value is None or isinstance(value, (bool, int)):
        return value
    raise ValueError("unexpected value type: " + type(value).__name__)


def validate_output(out):
    """Return a safe copy of the answer, or raise ValueError if it looks wrong."""
    if not isinstance(out, dict):
        raise ValueError("answer is not a dictionary")
    if "error" in out:
        return {"error": clean_text(out["error"], 300)}

    mode, task = out.get("mode"), out.get("task")
    if mode not in FORECAST_KEYS or task not in ("analysis", "forecast", "both"):
        raise ValueError("unknown mode or task")
    needed = ["notes"]
    if task != "analysis":
        needed += FORECAST_KEYS[mode]
    if task != "forecast":
        needed.append("analysis")
    missing = [k for k in needed if k not in out]
    if missing:
        raise ValueError("missing keys: " + ", ".join(missing))

    for key, limit in LIST_LIMITS.items():
        if out.get(key) is not None and len(out[key]) > limit:
            raise ValueError(key + " is too long")

    safe = _scrub(out)
    json.dumps(safe, allow_nan=False)
    return safe


def verify_captcha(token, ip, secret):
    """Ask Cloudflare Turnstile if this visitor passed the challenge.
    If anything goes wrong we say NO (fail closed)."""
    if not token or not secret:
        return False
    body = urllib.parse.urlencode(
        {"secret": secret, "response": token, "remoteip": ip}
    ).encode()
    request = urllib.request.Request(
        "https://challenges.cloudflare.com/turnstile/v0/siteverify", data=body
    )
    try:
        with urllib.request.urlopen(request, timeout=5) as response:
            return json.loads(response.read().decode()).get("success") is True
    except Exception:
        return False
